<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH C:\wamp64\www\PROJECTS\LARAVEL\ToDoList\resources\views/layouts/footer.blade.php ENDPATH**/ ?>